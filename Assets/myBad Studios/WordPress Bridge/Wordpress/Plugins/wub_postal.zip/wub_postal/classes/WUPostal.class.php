<?php

if (!class_exists('WUPostal')) {
	class WUPostal {
		const STRING_ARRAYS = array( 'tag_slug__and', 'tag_slug__in', 'post_name__in' );
		const UNWANTED_FIELDS = array( 'gid', 'unity', 'action', 'wfg', 'wuss', 'id', 'wub' );
		const IMAGEFORMATS = array( 'jpg', 'png', 'gif' );

		static function FetchPosts( $fetch_meta = false, $fetch_featured = true ) {
			$params = array();
			$output = '';

			if ( isset( $_REQUEST['fetch_meta'] ) ) {
				unset( $_REQUEST['fetch_meta'] );
			}

			if ( isset( $_REQUEST['fetch_featured'] ) ) {
				unset( $_REQUEST['fetch_featured'] );
			}
			$comment_count = array();

			foreach ( $_REQUEST as $k => $v ) {
				if ( in_array( $k, WUPostal::UNWANTED_FIELDS ) ) {
					continue;
				}
				if ( strpos( $k, '__' ) > 0 ) {
					if ( ! in_array( $v, WUPostal::STRING_ARRAYS ) ) {
						$params[ $k ] = explode( ",", $v );
						continue;
					}
				}
				switch ( $k ) {
					case "tax_query":
						$tax_string    = base64_decode( $v );
						$tax_query_arg = '';//wil be set via eval if possible
						eval( $tax_string );
						if ( $tax_query_arg != '' ) {
							$params["tax_query"] = $tax_query_arg;
						}
						break;

					case "orderby":
						$pairs   = explode( ",", $v );
						$orderby = array();
						foreach ( $pairs as $pair ) {
							$keyvaluepair                = explode( '=', $pair );
							$orderby[ $keyvaluepair[0] ] = $keyvaluepair[1];
						}
						$params[ $k ] = $orderby;
						break;

					case "comment_count":
						$comment_count['value'] = $v;
						$ccop = Posted('comment_operator');
						$comment_count['compare'] = $ccop == '' ? '=' : $ccop;
						$params[$k] = $comment_count;
						break;
					case 'comment_operator':
						//already used so do nothing
						break;

					case 'date_query':
						$date_query = base64_decode($v);
						$date_query_arr = '';
						if (substr($date_query,-1) == ',')
							$date_query = substr($date_query,0,strlen($date_query)-1);
						echo '$date_query_arr = '.$date_query.';';
						eval('$date_query_arr = '.$date_query.';');
						$params[$k] = $date_query_arr;
						break;

					default:

						switch ( $v ) {
							case "false":
								$params[ $k ] = false;
								break;
							case "true":
								$params[ $k ] = true;
								break;
							case "null":
								$params[ $k ] = null;
								break;
							default:
								$params[ $k ] = $v;
								break;
						}
						break;
				}
			}

			$query = new WP_Query( $params );
			if ( $query->have_posts() ) {
				while ( $query->have_posts() ) {
					$query->the_post();
					$post   = $query->post;
					$output .= SendNode( "POST" );
					foreach ( $post as $k => $v ) {
						if ( $k != "post_password" ) {
							switch ( $k ) {
								case "filter":
								case "post_excerpt":
									$output .= SendField( $k, base64_encode( $v ) );
									break;

								case "post_content":
									$temp_content = str_replace( '<!--more-->', '', $v );
									$temp_content = apply_filters( 'the_content', $temp_content );
									$temp_content = str_replace( ']]>', ']]&gt;', $temp_content );
									$output       .= SendField( $k, base64_encode( $temp_content ) );
									break;

								default:
									$output .= SendField( $k, $v );
									break;
							}
						}
					}

					if ( $fetch_meta ) {
						$postmeta = get_post_meta( $post->ID );
						if ( $postmeta ) {
							$output .= SendNode( "POSTMETA" );
							foreach ( $postmeta as $metainfo => $metadata ) {
								$output .= SendField( $metainfo, join( '|', $metadata ) );
							}
						}
					}

					if ( $fetch_featured ) {
						$post_thumbnail_id = get_post_thumbnail_id( $post->ID );
						$size              = apply_filters( 'post_thumbnail_size', $fetch_featured );
						if ( $post_thumbnail_id ) {
							$src    = join( ',', wp_get_attachment_image_src( $post_thumbnail_id, $size ) );
							$output .= SendField( "featured", $src );
						}
					}
				}
			} else {
				$message = "No results returned " . print_r( $params, true );
				SendToUnity( PrintError( $message ) ) ;
				return;
			}
			SendToUnity( $output );
		}

		static private function __getPostArguments( $fields ) {
			if ( ! $fields ) {
				return array();
			}

			$arguments = array();
			foreach ( $fields as $k => $v ) {
				switch ( $k ) {
					case "post_content":
					case "post_excerpt":
						$arguments[ $k ] = base64_decode( $v );
						break;

					case "post_title":
						$arguments[ $k ] = wp_strip_all_tags( base64_decode( $v ) );
						break;

					default:
						$arguments[ $k ] = $v;
						break;
				}
			}

			return $arguments;
		}

		static function MakePost( $post_type, $arguments ) {
			if ( ( $post_type == 'post' && ! current_user_can( 'publish_posts' ) ) ||
			     ( $post_type == 'page' && ! current_user_can( 'publish_pages' ) ) ) {
				SendToUnity( PrintError( "You do not have sufficient publishing capabilities on this site" ) );
				return;
			}

			$arguments = WUPostal::__getPostArguments( $arguments );

			$post_id  = wp_insert_post( $arguments, true );
			$response = '';

			if ( is_wp_error( $post_id ) ) {
				SendToUnity( PrintError( $post_id->get_error_message() ) );
				return;
			}

			foreach ( $arguments as $k => $v ) {
				$response .= Sendfield( $k, $v );
			}
			$response .= SendField( "pid", $post_id );

			SendToUnity( $response );
		}

		static function AssignPostThumbnail( $pid, $iid ) {
			$result = set_post_thumbnail( $pid, $iid );
			if ( $result === false ) {
				SendToUnity( PrintError( "Unable to set the featured image of post $pid to attachment $iid" ) );
			} else {
				SendToUnity( '' );
			}
		}

		static function UploadAttachment( $uid, $filename, $extension, $content, $post_parent_id = false ) {
			$extension = strtolower( $extension );
			if ( ! in_array( $extension, WUPostal::IMAGEFORMATS ) ) {
				SendToUnity( PrintError( 'Invalid file format', "Err_1" ) );
				return;
			}

			if ( false === $post_parent_id || ! is_numeric( $post_parent_id ) )
				$post_parent_id = 0;

			if ( $post_parent_id > 0 && null == get_post( $post_parent_id ) )
				$post_parent_id = 0;

			$user = get_user_by( 'ID', $uid );
			if ( ! $user ) {
				SendToUnity( PrintError( 'User not found', "Err_2" ) );
				return;
			}

			//if (!user_can($uid, 'unfiltered_upload' )) return false;
			//die(SendToUnity( PrintError( 'User not authorized to upload content' ) ) );

			$filename      = trim( $filename );
			$filename      = str_replace( ' ', '_', $filename );
			$upload_folder = self::GetUserUploadFolder( $user );
			$output_file   = "{$upload_folder}{$filename}.{$extension}";
			if ( file_exists( $output_file ) ) {
				$copy = 1;
				while ( file_exists( "{$upload_folder}{$filename}_copy{$copy}.{$extension}" ) ) {
					++ $copy;
				}
				$output_file = "{$upload_folder}{$filename}_copy{$copy}.{$extension}";
			}

			file_put_contents( $output_file, base64_decode( $content ) );
			$response = self::media_image_upload( $output_file, $post_parent_id );
			if ( is_wp_error( $response ) ) {
				SendToUnity( PrintError( $response->get_error_message(), "Err_3" ) );
				unlink( $output_file );
				return;
			}
			SendToUnity( SendField( 'attachment_id', $response ) );
		}

		static private function GetUserUploadFolder( $user ) {
			$upload_dir   = wp_upload_dir( 'basedir' );
			$user_dirname = $upload_dir['basedir'];
			if ( null !== $user ) {
				$user_dirname .= "/{$user->user_login}";
				$user_dirname = str_replace( ' ', '_', $user_dirname );
				if ( ! file_exists( $user_dirname ) ) {
					wp_mkdir_p( $user_dirname );
				}
			}

			return $user_dirname . '/';
		}

		static private function media_image_upload( $filename, $post_id ) {
			include_once( ABSPATH . 'wp-admin/includes/image.php' );
			$name = $filename;
			$ext  = pathinfo( $name, PATHINFO_EXTENSION );
			$name = wp_basename( $name, ".$ext" );

			$url = esc_url_raw(
				str_replace(
					wp_normalize_path( untrailingslashit( ABSPATH ) ),
					site_url(),
					wp_normalize_path( $filename )
				)
			);

			$type    = "image/{$ext}";
			$title   = sanitize_text_field( $name );
			$content = '';
			$excerpt = '';

			$image_meta = wp_read_image_metadata( $filename );
			if ( $image_meta ) {
				if ( trim( $image_meta['title'] ) && ! is_numeric( sanitize_title( $image_meta['title'] ) ) ) {
					$title = $image_meta['title'];
				}

				if ( trim( $image_meta['caption'] ) ) {
					$excerpt = $image_meta['caption'];
				}
			}

			$attachment    = array(
				'post_mime_type' => $type,
				'guid'           => $url,
				'post_parent'    => $post_id,
				'post_title'     => $title,
				'post_content'   => $content,
				'post_excerpt'   => $excerpt,
			);
			$uploaddir = trailingslashit(wp_upload_dir()['basedir']);
			$relpath = str_replace($uploaddir, '', $filename);
			$attachment_id = wp_insert_attachment( $attachment, $relpath, $post_id, true );

			if ( ! is_wp_error( $attachment_id ) ) {
				// The image sub-sizes are created during wp_generate_attachment_metadata().
				// This is generally slow and may cause timeouts or out of memory errors.
				wp_update_attachment_metadata( $attachment_id, wp_generate_attachment_metadata( $attachment_id, $filename ) );
			}

			return $attachment_id;
		}
	}
}

<?php
//load this first as this makes sure the WP themes are not processed
$filepath = dirname(__FILE__) . "/../wordpress_for_unity/unitysettings.php";
if (!file_exists($filepath))
	$filepath = dirname( __FILE__ ) . "/../wub_login/settings.php";

if (file_exists($filepath))
	require_once($filepath);

function postalFetchPosts()
{
	if (!function_exists('Posted')) echo "POSTED DOESNT EXIST";
	$fetch_meta     = Posted( 'fetch_meta' ) == 'true';
	$fetch_featured = Posted( 'fetch_featured' ) != 'false';
	WUPostal::FetchPosts($fetch_meta, $fetch_featured);
}

function postalMakePost()
{
	$post_type = strtolower(Posted("post_type"));
	if ($post_type == '')
		$post_type = 'post';
	$_REQUEST['post_type'] = $post_type;
	WUPostal::MakePost($post_type, $_REQUEST);
}

function postalSpecifyFeaturedImage()
{
	$pid = Postedi('post_id');
	$iid = Postedi('image_id');
	WUPostal::AssignPostThumbnail($pid,$iid);
}

function postalUploadFeaturedImage()
{
	$uid =  Postedi('uid');
	$filename =  Posted('filename');
	$extension =  Posted('extension');
	$content =  Posted('content');
	$post_id =  Postedi('post_id');
	if ($post_id == 0) $post_id = false;
	WUPostal::UploadAttachment($uid, $filename, $extension, $content, $post_id);
}


<?php
/*
Plugin Name: WordPress for Unity Bridge - POSTAL
Plugin URI: https://mybadstudios.com/
Description: POST table reading and writing from within Unity
Version: 1.0
Network: true
Author: myBad Studios
Author URI: https://www.mybadstudios.com
*/

spl_autoload_register(function ($class_name) {
	$filepath = plugin_dir_path(__FILE__). 'classes/'. $class_name . '.class.php';
	if (file_exists($filepath))
		include_once( $filepath );
});
